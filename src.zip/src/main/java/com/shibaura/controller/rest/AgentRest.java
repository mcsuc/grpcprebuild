package com.shibaura.controller.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.system.ApplicationHome;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@RestController
@RequestMapping("/agent")
@CrossOrigin(origins="*")
public class AgentRest {
    public static final Logger logger = LoggerFactory.getLogger(AgentRest.class);

    @PostMapping("/recheck")
    public ResponseEntity<String> recheck(
            @RequestParam("cmd") String cmd,
            @RequestParam("file1") MultipartFile file1,
            @RequestParam("file2") MultipartFile file2) throws URISyntaxException, IOException {
      String fileName1 = file1.getOriginalFilename();
      String fileName2 = file2.getOriginalFilename();

      Path jarDir;
      ApplicationHome home = new ApplicationHome(AgentRest.class);
      File jarFile = home.getSource();
      if(jarFile!=null){
          jarDir = jarFile.toPath().getParent();
      }else{
          jarDir = getJarDirectory();
      }
      logger.info("Current Dir1:{}", jarDir.toAbsolutePath());

      Path dataDir = jarDir.resolve("data");
      if(!Files.exists(dataDir)){
          Files.createDirectory(dataDir);
      }

      Path filePath1 = dataDir.resolve(fileName1);
      Path filePath2 = dataDir.resolve(fileName2);

      try{
          Files.write(filePath1, file1.getBytes());
          Files.write(filePath2, file2.getBytes());

          String testResult = "{"+
                  " \"CAMID\": \"Cam01\"," +
                  " \"LOCATION\": \"Wafer\"," +
                  " \"REVIEWRESULT\": \"OK\"," +
                  " \"POINT\": \"1\"," +
                  " \"BGINSP_MARKTYPE\": \"IC\"," +
                  " \"FRAME_MAP_XY\": \"-3,7\"," +
                  " \"WAFER_MAP_XY\": \"5,-2\"," +
                  " \"RESULT_XYV\": \"123.12,-123.12,567\"," +
                  "}";
          return new ResponseEntity<>(testResult, HttpStatus.OK);
      }catch(Exception ex){
          return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Upload Fails:"+ ex.getMessage());
      }
    }

    public Path getJarDirectory() throws URISyntaxException {
        Path jarPath = Paths.get(
                AgentRest.class
                        .getProtectionDomain()
                        .getCodeSource()
                        .getLocation()
                        .toURI())
                .toAbsolutePath();
        return jarPath;
    }
}
